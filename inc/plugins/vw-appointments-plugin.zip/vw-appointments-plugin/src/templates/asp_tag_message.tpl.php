<div class="error error-warning">
    <p><strong>VwAppointmentPlugins Error Message</strong>. You have APS tags turned on inside yours PHP settings. Please turn it off before you continue with using VwAppointmentPlugins. ASP tags are deprecated option and it is removed in latest version of PHP (7.0). More details on <a
            href="https://vw-appointments-plugin.net/faq/#blank-admin-pages"
            target="_blank">LINK</a></p>
</div>