<?php 
/**
 * Initialize the front output data
 */

function vwsmp_front_data_init() {

	// Globle Variable
	global $vwsmp_options;

	// Enable/Disable
	$onoff_enable = $vwsmp_options['vwsmp_admin_check_enable'];
	if($onoff_enable == 1){  

		// Position Variable
		$position_center = $vwsmp_options['vwsmp_admin_radio'];

		// Icon Style Variable
		$icon_style = $vwsmp_options['vwsmp_admin_radio_style'];

		// Style Option
		$color_options = $vwsmp_options['vwsmp_color'];
		$color_hover = $vwsmp_options['vwsmp_hover_color'];
		$background_options = $vwsmp_options['vwsmp_background_color'];
		$background_hover = $vwsmp_options['vwsmp_background_hover_color'];
		$font_options = $vwsmp_options['vwsmp_font_size'];
		$radius_options = $vwsmp_options['vwsmp_border_radius'];
		$margin_top = $vwsmp_options['vwsmp_margin_top'];
		$margin_right = $vwsmp_options['vwsmp_margin_right'];
		$margin_bottom = $vwsmp_options['vwsmp_margin_bottom'];
		$margin_left = $vwsmp_options['vwsmp_margin_left'];

		$vwsmp_margin = 'margin:0'.$margin_top.'px 0'.$margin_right.'px 0'.$margin_bottom.'px 0'.$margin_left.'px;';
		$vwsmp_style_con =  'color:'.$color_options.';background-color:'.$background_options.'; font-size:'.$font_options.'px;border-radius:'.$radius_options.'px;'.$vwsmp_margin;
		?>

		<style type="text/css"> 
			.vwsmp a:hover{
				color: <?php echo $color_hover;  ?> !important;
				background-color: <?php echo $background_hover;  ?> !important;
			}
		</style>

		<div id="style-2" class="vwsmp <?php echo esc_attr($position_center); ?>">

			<?php
			// Facebook
			$onoff_facebook = $vwsmp_options['vwsmp_admin_check_facebook'];
			if($onoff_facebook == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_facebook'] != ''){ ?>
			    	<a class="vwsmp_facebook <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_facebook']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?> " target="_blank"><i class="fab fa-facebook-f"></i>
			    	</a>
			    <?php } 
			} 

			// Twitter
			$onoff_twitter = $vwsmp_options['vwsmp_admin_check_twitter'];
			if($onoff_twitter == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_twitter'] != ''){ ?>
			    	<a class="vwsmp_twitter <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_twitter']); ?>" style= "<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-twitter"></i>
			    	</a>
			    <?php } 
			} 

			// Google+
			$onoff_google = $vwsmp_options['vwsmp_admin_check_google'];
			if($onoff_google == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_google'] != ''){ ?>
			    	<a class="vwsmp_google <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_google']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-google-plus-g"></i>
			    	</a>
			    <?php } 
			} 

			// Instagram
			$onoff_instagram = $vwsmp_options['vwsmp_admin_check_instagram'];
			if($onoff_instagram == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_instagram'] != ''){ ?>
			    	<a class="vwsmp_instagram <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_instagram']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-instagram"></i>
			    	</a>
			    <?php } 
			} 

			// Flickr
			$onoff_flickr = $vwsmp_options['vwsmp_admin_check_flickr'];
			if($onoff_flickr == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_flickr'] != ''){ ?>
			    	<a class="vwsmp_flickr <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_flickr']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-flickr"></i>
			    	</a>
			    <?php } 
			} 

			// Pintrest
			$onoff_pinterest = $vwsmp_options['vwsmp_admin_check_pinterest'];
			if($onoff_pinterest == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_pinterest'] != ''){ ?>
			    	<a class="vwsmp_pinterest <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_pinterest']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-pinterest-p"></i>
			    	</a>
			    <?php } 
			} 

			// YouTube
			$onoff_youtube = $vwsmp_options['vwsmp_admin_check_youtube'];
			if($onoff_youtube == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_youtube'] != ''){ ?>
			    	<a class="vwsmp_youtube <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_youtube']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-youtube"></i>
			    	</a>
			    <?php } 
			} 

			// Skype
			$onoff_skype = $vwsmp_options['vwsmp_admin_check_skype'];
			if($onoff_skype == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_skype'] != ''){ ?>
			    	<a class="vwsmp_skype <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_skype']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-skype"></i>
			    	</a>
			    <?php } 
			} 

			// Tumblr
			$onoff_tumblr = $vwsmp_options['vwsmp_admin_check_tumblr'];
			if($onoff_tumblr == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_tumblr'] != ''){ ?>
			    	<a class="vwsmp_tumblr <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_tumblr']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-tumblr"></i>
			    	</a>
			    <?php } 
			} 

			// Wordpress
			$onoff_wordpress = $vwsmp_options['vwsmp_admin_check_wordpress'];
			if($onoff_wordpress == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_wordpress'] != ''){ ?>
			    	<a class="vwsmp_wordpress <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_wordpress']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-wordpress"></i>
			    	</a>
			    <?php } 
			} 

			// RSS
			$onoff_rss = $vwsmp_options['vwsmp_admin_check_rss'];
			if($onoff_rss == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_rss'] != ''){ ?>
			    	<a class="vwsmp_rss <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_rss']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fas fa-rss"></i>
			    	</a>
			    <?php } 
			} 

			// VK
			$onoff_vk = $vwsmp_options['vwsmp_admin_check_vk'];
			if($onoff_vk == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_vk'] != ''){ ?>
			    	<a class="vwsmp_vk <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_vk']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-vk"></i>
			    	</a>
			    <?php } 
			}

			// Custom Icon 1
			$onoff_icon_1 = $vwsmp_options['vwsmp_admin_check_custom_1'];
			$vwsmp_custom_1_icon = $vwsmp_options['vwsmp_custom_1_icon'];
			if($onoff_icon_1 == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_custom_1'] != ''){ ?>
			    	<a class="vwsmp_custom_1 <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_custom_1']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?> " target="_blank"><i class="<?php echo esc_attr($vwsmp_custom_1_icon); ?>"></i>
			    	</a>
			    <?php } 
			} 

			// Custom Icon 2
			$onoff_icon_2 = $vwsmp_options['vwsmp_admin_check_custom_2'];
			$vwsmp_custom_2_icon = $vwsmp_options['vwsmp_custom_2_icon'];
			if($onoff_icon_2 == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_custom_2'] != ''){ ?>
			    	<a class="vwsmp_custom_2 <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_custom_2']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?> " target="_blank"><i class="<?php echo esc_attr($vwsmp_custom_2_icon); ?>"></i>
			    	</a>
			    <?php } 
			} 

			// Custom Icon 1
			$onoff_icon_3 = $vwsmp_options['vwsmp_admin_check_custom_3'];
			$vwsmp_custom_3_icon = $vwsmp_options['vwsmp_custom_3_icon'];
			if($onoff_icon_3 == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_custom_3'] != ''){ ?>
			    	<a class="vwsmp_custom_3 <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_custom_3']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?> " target="_blank"><i class="<?php echo esc_attr($vwsmp_custom_3_icon); ?>"></i>
			    	</a>
			    <?php } 
			} 

			// Custom Icon 4
			$onoff_icon_4 = $vwsmp_options['vwsmp_admin_check_custom_4'];
			$vwsmp_custom_4_icon = $vwsmp_options['vwsmp_custom_4_icon'];
			if($onoff_icon_4 == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_custom_4'] != ''){ ?>
			    	<a class="vwsmp_custom_4 <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_custom_4']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?> " target="_blank"><i class="<?php echo esc_attr($vwsmp_custom_4_icon); ?>"></i>
			    	</a>
			    <?php } 
			} 

			// Custom Icon 5
			$onoff_icon_5 = $vwsmp_options['vwsmp_admin_check_custom_5'];
			$vwsmp_custom_5_icon = $vwsmp_options['vwsmp_custom_5_icon'];
			if($onoff_icon_5 == 1){ ?>
			    <?php if($vwsmp_options['vwsmp_custom_5'] != ''){ ?>
			    	<a class="vwsmp_custom_5 <?php echo esc_attr($icon_style); ?>" href="<?php echo esc_url($vwsmp_options['vwsmp_custom_5']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?> " target="_blank"><i class="<?php echo esc_attr($vwsmp_custom_5_icon); ?>"></i>
			    	</a>
			    <?php } 
			} 
			?>
		</div><?php 
	}
}
add_action( 'wp_footer', 'vwsmp_front_data_init', 99 );