<?php 

// Shortcode to show the form
add_shortcode("vwsmp-social-media", "vwsmp_social_media_short");

function vwsmp_social_media_short( $atts){ 

	$atts = shortcode_atts(
	array(
		'color' => 'no color',
		'hover_color' => 'no hover_color',
		'bg_color' => 'no bg_color',
		'bg_hover_color' => 'no bg_hover_color',
		'font_size' => 'no font_size',
		'border_radius' => 'no border_radius',
		'left_margin' => 'no left_margin',
		'right_margin' => 'no right_margin',
		'top_margin' => 'no top_margin',
		'bottom_margin' => 'no bottom_margin',
		'width' => 'no vwsmp_width',
		'height' => 'no vwsmp_height',

	),$atts, 'vwsmp-social-media' );

	//  Plugin data
	global $vwsmp_options;	

	$vwsmp_style_con =  'color:'.$atts['color'].';background-color:'.$atts['bg_color'].';font-size:'.$atts['font_size'].'px; border-radius:'.$atts['border_radius'].'px;margin-left:'.$atts['left_margin'].'px;margin-right:'.$atts['right_margin'].'px;margin-bottom:'.$atts['bottom_margin'].'px; margin-top:'.$atts['top_margin'].'px;width:'.$atts['width'].'px;height:'. $atts['height'].'px;';	
	?>

	<style type="text/css"> 
		.vwsmp_front a:hover{
			color: <?php echo $atts['hover_color'];  ?> !important;
			background-color: <?php echo $atts['bg_hover_color'];  ?> !important;
		}
	</style>

	<div class="vwsmp_front">

		<?php
		// Facebook
		$onoff_facebook = $vwsmp_options['vwsmp_admin_check_facebook'];
		if($onoff_facebook == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_facebook'] != ''){ ?>
		    	<a class="vwsmp_facebook" href="<?php echo esc_url($vwsmp_options['vwsmp_facebook']); ?>" style= "<?php echo esc_attr($vwsmp_style_con); ?>"  target="_blank"><i class="fab fa-facebook-f"></i>
		    	</a>
		    <?php } 
		}

		// Twitter
		$onoff_twitter = $vwsmp_options['vwsmp_admin_check_twitter'];
		if($onoff_twitter == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_twitter'] != ''){ ?>
		    	<a class="vwsmp_twitter" href="<?php echo esc_url($vwsmp_options['vwsmp_twitter']); ?>" style= "<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-twitter"></i>
		    	</a>
		    <?php } 
		} 

		// Google+
		$onoff_google = $vwsmp_options['vwsmp_admin_check_google'];
		if($onoff_google == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_google'] != ''){ ?>
		    	<a class="vwsmp_google" href="<?php echo esc_url($vwsmp_options['vwsmp_google']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-google-plus-g"></i>
		    	</a>
		    <?php } 
		} 

		// Instagram
		$onoff_instagram = $vwsmp_options['vwsmp_admin_check_instagram'];
		if($onoff_instagram == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_instagram'] != ''){ ?>
		    	<a class="vwsmp_instagram" href="<?php echo esc_url($vwsmp_options['vwsmp_instagram']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-instagram"></i>
		    	</a>
		    <?php } 
		} 

		// Flickr
		$onoff_flickr = $vwsmp_options['vwsmp_admin_check_flickr'];
		if($onoff_flickr == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_flickr'] != ''){ ?>
		    	<a class="vwsmp_flickr" href="<?php echo esc_url($vwsmp_options['vwsmp_flickr']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-flickr"></i>
		    	</a>
		    <?php } 
		} 

		// Pintrest
		$onoff_pinterest = $vwsmp_options['vwsmp_admin_check_pinterest'];
		if($onoff_pinterest == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_pinterest'] != ''){ ?>
		    	<a class="vwsmp_pinterest" href="<?php echo esc_url($vwsmp_options['vwsmp_pinterest']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-pinterest-p"></i>
		    	</a>
		    <?php } 
		} 

		// YouTube
		$onoff_youtube = $vwsmp_options['vwsmp_admin_check_youtube'];
		if($onoff_youtube == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_youtube'] != ''){ ?>
		    	<a class="vwsmp_youtube" href="<?php echo esc_url($vwsmp_options['vwsmp_youtube']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-youtube"></i>
		    	</a>
		    <?php } 
		} 

		// Skype
		$onoff_skype = $vwsmp_options['vwsmp_admin_check_skype'];
		if($onoff_skype == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_skype'] != ''){ ?>
		    	<a class="vwsmp_skype" href="<?php echo esc_url($vwsmp_options['vwsmp_skype']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-skype"></i>
		    	</a>
		    <?php } 
		} 

		// Tumblr
		$onoff_tumblr = $vwsmp_options['vwsmp_admin_check_tumblr'];
		if($onoff_tumblr == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_tumblr'] != ''){ ?>
		    	<a class="vwsmp_tumblr" href="<?php echo esc_url($vwsmp_options['vwsmp_tumblr']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-tumblr"></i>
		    	</a>
		    <?php } 
		} 

		// Wordpress
		$onoff_wordpress = $vwsmp_options['vwsmp_admin_check_wordpress'];
		if($onoff_wordpress == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_wordpress'] != ''){ ?>
		    	<a class="vwsmp_wordpress" href="<?php echo esc_url($vwsmp_options['vwsmp_wordpress']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-wordpress"></i>
		    	</a>
		    <?php } 
		} 

		// RSS
		$onoff_rss = $vwsmp_options['vwsmp_admin_check_rss'];
		if($onoff_rss == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_rss'] != ''){ ?>
		    	<a class="vwsmp_rss" href="<?php echo esc_url($vwsmp_options['vwsmp_rss']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fas fa-rss"></i>
		    	</a>
		    <?php } 
		} 

		// VK
		$onoff_vk = $vwsmp_options['vwsmp_admin_check_vk'];
		if($onoff_vk == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_vk'] != ''){ ?>
		    	<a class="vwsmp_vk " href="<?php echo esc_url($vwsmp_options['vwsmp_vk']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="fab fa-vk"></i>
		    	</a>
		    <?php } 
		}

		// Custom Icon 1
		$onoff_custom_1 = $vwsmp_options['vwsmp_admin_check_custom_1'];
		$vwsmp_custom_1_icon = $vwsmp_options['vwsmp_custom_1_icon'];
		if($onoff_custom_1 == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_custom_1'] != ''){ ?>
		    	<a class="vwsmp_custom_1 " href="<?php echo esc_url($vwsmp_options['vwsmp_custom_1']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="<?php echo esc_attr($vwsmp_custom_1_icon); ?>"></i>
		    	</a>
		    <?php } 
		}	

		// Custom Icon 2
		$onoff_custom_2 = $vwsmp_options['vwsmp_admin_check_custom_2'];
		$vwsmp_custom_2_icon = $vwsmp_options['vwsmp_custom_2_icon'];
		if($onoff_custom_2 == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_custom_2'] != ''){ ?>
		    	<a class="vwsmp_custom_2 " href="<?php echo esc_url($vwsmp_options['vwsmp_custom_2']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="<?php echo esc_attr($vwsmp_custom_2_icon); ?>"></i>
		    	</a>
		    <?php } 
		}	

		// Custom Icon 3
		$onoff_custom_3 = $vwsmp_options['vwsmp_admin_check_custom_3'];
		$vwsmp_custom_3_icon = $vwsmp_options['vwsmp_custom_3_icon'];
		if($onoff_custom_3 == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_custom_3'] != ''){ ?>
		    	<a class="vwsmp_custom_3 " href="<?php echo esc_url($vwsmp_options['vwsmp_custom_3']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="<?php echo esc_attr($vwsmp_custom_3_icon); ?>"></i>
		    	</a>
		    <?php } 
		}

		// Custom Icon 4
		$onoff_custom_4 = $vwsmp_options['vwsmp_admin_check_custom_4'];
		$vwsmp_custom_4_icon = $vwsmp_options['vwsmp_custom_4_icon'];
		if($onoff_custom_4 == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_custom_4'] != ''){ ?>
		    	<a class="vwsmp_custom_4 " href="<?php echo esc_url($vwsmp_options['vwsmp_custom_4']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="<?php echo esc_attr($vwsmp_custom_4_icon); ?>"></i>
		    	</a>
		    <?php } 
		}

		// Custom Icon 5
		$onoff_custom_5 = $vwsmp_options['vwsmp_admin_check_custom_5'];
		$vwsmp_custom_5_icon = $vwsmp_options['vwsmp_custom_5_icon'];
		if($onoff_custom_5 == 1){ ?>
		    <?php if($vwsmp_options['vwsmp_custom_5'] != ''){ ?>
		    	<a class="vwsmp_custom_5 " href="<?php echo esc_url($vwsmp_options['vwsmp_custom_5']); ?>" style="<?php echo esc_attr($vwsmp_style_con); ?>" target="_blank"><i class="<?php echo esc_attr($vwsmp_custom_5_icon); ?>"></i>
		    	</a>
		    <?php } 
		}
		?> 
	</div><?php 
}